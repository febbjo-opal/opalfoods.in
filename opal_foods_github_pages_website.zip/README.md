# Opal Foods website

A responsive, static website for Opal Foods, designed for free hosting with GitHub Pages and a custom GoDaddy domain.

## Before publishing
1. Open `index.html`.
2. Find `YOUR-EMAIL@example.com` and replace it with your business email address in both places.
3. Update the product categories and wording as your actual catalogue becomes available.
4. Add a phone/WhatsApp contact if you want one (none has been invented in this template).

## Publish free using GitHub Pages
1. Sign in at https://github.com and create a new **public** repository, for example `opal-foods-website`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to the repository's root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for GitHub to show your published site URL.

## Connect your GoDaddy domain
1. In GitHub, open **Settings → Pages → Custom domain** and enter your exact domain (for example `opalfood.in`), then save.
2. In GoDaddy, open your domain's **DNS Management**.
3. For the root/apex domain, add these four A records, each with Host `@`:
   - `185.199.108.153`
   - `185.199.109.153`
   - `185.199.110.153`
   - `185.199.111.153`
4. Add a CNAME record with Host `www` and Value `<your-GitHub-username>.github.io` (replace with your actual GitHub username; no `https://`).
5. Remove conflicting A/CNAME records for `@` or `www` only if they conflict with these settings. Do not delete MX records used by your email.
6. DNS changes can take time to propagate. Return to GitHub Pages and enable **Enforce HTTPS** when it becomes available.

DNS setup can vary depending on whether you use the root domain, `www`, or both. Follow GitHub's current Pages documentation if its instructions differ: https://docs.github.com/pages/configuring-a-custom-domain-for-your-github-pages-site

## Notes
- Hosting is free on GitHub Pages for a public repository.
- This is a catalogue/information website, not a shopping cart or online payment system.
- The website uses Google Fonts when internet access is available; the layout remains usable without them.
